"""
The three functions your algorithm calls.

    batch_id = submit_for_review(raw, corrected, id_col="order_id", target="duration_min", ...)
        -> after the safeguard runs: diffs the data, runs detection, stores a batch
           that a human reviews on the website.

    df = get_active_dataset()
        -> the most recent human-APPROVED dataset (None until someone approves).
           Train / serve from this instead of the raw corrected output.

    o = get_reviewer_overrides()
        -> reviewer findings to apply on the next safeguard run:
           disabled_rules, thresholds, source_trust, excluded_rows.
"""
from __future__ import annotations

import pandas as pd

from .config import ReviewConfig
from .detectors import run_detectors
from .ledger import diff_to_changes
from .store import ReviewStore

_STORE: ReviewStore | None = None


def get_store() -> ReviewStore:
    global _STORE
    if _STORE is None:
        _STORE = ReviewStore()
    return _STORE


def submit_for_review(raw: pd.DataFrame, corrected: pd.DataFrame, *, id_col: str, target: str,
                      group_col: str | None = None, trusted: pd.DataFrame | None = None,
                      distance_col: str | None = None, weight_col: str = "weight",
                      defer_col: str = "deferred", rule_col: str = "_rule", reason_col: str = "_reason",
                      field_rules: dict | None = None,
                      title: str = "", scenario: str = "", cfg: ReviewConfig | None = None,
                      store: ReviewStore | None = None) -> str:
    store = store or get_store()
    changes = diff_to_changes(raw, corrected, id_col, group_col=group_col, rule_col=rule_col,
                              reason_col=reason_col, weight_col=weight_col, defer_col=defer_col,
                              field_rules=field_rules)
    alerts, status = run_detectors(raw, corrected, changes, id_col=id_col, target=target,
                                   group_col=group_col, trusted=trusted, distance_col=distance_col,
                                   weight_col=weight_col, defer_col=defer_col, cfg=cfg)
    meta = {"title": title or f"Safeguard output · {scenario or 'run'}", "scenario": scenario,
            "columns": {"id_col": id_col, "target": target, "group_col": group_col,
                        "weight_col": weight_col, "defer_col": defer_col, "distance_col": distance_col}}
    return store.create(raw, corrected, changes, alerts, status, meta, trusted)


def get_active_dataset(store: ReviewStore | None = None) -> pd.DataFrame | None:
    a = (store or get_store()).active()
    return pd.read_csv(a["path"]) if a else None


def get_reviewer_overrides(store: ReviewStore | None = None) -> dict:
    return (store or get_store()).overrides()

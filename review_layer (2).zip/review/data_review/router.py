"""
FastAPI routes for the human review console. Mount with:

    from data_review.router import router as review_router
    app.include_router(review_router)          # serves /api/review/...
"""
from __future__ import annotations

import io
import json
from typing import Literal

import pandas as pd
from fastapi import APIRouter, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import PlainTextResponse, StreamingResponse
from pydantic import BaseModel, Field

from .demo import make_demo
from .pipeline import get_store, submit_for_review
from .store import ReviewError

router = APIRouter(prefix="/api/review", tags=["data review"])
PREVIEW_IDS = 25


def _guard(fn):
    try:
        return fn()
    except ReviewError as e:
        raise HTTPException(400, str(e))
    except KeyError as e:
        raise HTTPException(404, f"not found: {e}")


class Verdicts(BaseModel):
    change_ids: list[str] | None = None
    rule: str | None = None
    verdict: Literal["pending", "accepted", "rejected"]
    note: str = ""
    reviewer: str = "reviewer"


class Finding(BaseModel):
    type: Literal["disable_rule", "set_threshold", "source_trust", "exclude_rows", "note"]
    target: str = ""
    value: str = ""
    text: str = ""


class Decision(BaseModel):
    decision: Literal["accept", "reject"]
    reviewer: str
    notes: str = ""
    acknowledge_alerts: bool = False
    findings: list[Finding] = Field(default_factory=list)


@router.get("/batches")
def list_batches():
    return get_store().list()


@router.post("/demo")
def create_demo():
    raw, cor, trusted, field_rules = make_demo()
    bid = submit_for_review(raw, cor, id_col="order_id", target="duration_min", group_col="region_id",
                            trusted=trusted, distance_col="distance_km", field_rules=field_rules,
                            title="DEMO · synthetic safeguard run", scenario="demo")
    return get_store().meta(bid)


@router.post("/batches/upload")
async def upload_batch(raw: UploadFile = File(...), corrected: UploadFile = File(...),
                       trusted: UploadFile | None = File(None), id_col: str = Form(...),
                       target: str = Form(...), group_col: str = Form(""), distance_col: str = Form(""),
                       title: str = Form("Uploaded batch")):
    r = pd.read_csv(io.BytesIO(await raw.read()))
    c = pd.read_csv(io.BytesIO(await corrected.read()))
    t = pd.read_csv(io.BytesIO(await trusted.read())) if trusted is not None else None
    for col in (id_col, target):
        if col not in r.columns or col not in c.columns:
            raise HTTPException(400, f"column {col!r} missing from raw or corrected")
    bid = submit_for_review(r, c, id_col=id_col, target=target, group_col=group_col or None,
                            distance_col=distance_col or None, trusted=t, title=title, scenario="upload")
    return get_store().meta(bid)


@router.get("/batches/{bid}")
def batch(bid: str):
    def go():
        s = get_store()
        alerts = []
        for a in s.alerts(bid):
            alerts.append({**a, "row_count": len(a["row_ids"]), "row_ids": a["row_ids"][:PREVIEW_IDS]})
        return {"meta": s.meta(bid), "alerts": alerts}
    return _guard(go)


@router.get("/batches/{bid}/rules")
def rules(bid: str):
    def go():
        ch = get_store().changes(bid)
        out = []
        for rule, g in ch.groupby("rule"):
            out.append({"rule": rule, "changes": int(len(g)), "rows": int(g["row_id"].nunique()),
                        "actions": g["action"].value_counts().to_dict(), "fields": sorted(g["field"].unique()),
                        "verdicts": g["verdict"].value_counts().to_dict(),
                        "example_reason": g["reason"].iloc[0]})
        return sorted(out, key=lambda r: -r["changes"])
    return _guard(go)


@router.get("/batches/{bid}/changes")
def changes(bid: str, action: str = "", field: str = "", rule: str = "", group: str = "",
            verdict: str = "", q: str = "", alert: str = "", page: int = Query(1, ge=1),
            size: int = Query(50, ge=1, le=500)):
    def go():
        s = get_store()
        ch = s.changes(bid)
        facets = {k: ch[k].value_counts().to_dict() for k in ("action", "field", "rule", "verdict", "group")}
        m = pd.Series(True, index=ch.index)
        for col, val in (("action", action), ("field", field), ("rule", rule), ("group", group), ("verdict", verdict)):
            if val:
                m &= ch[col] == val
        if alert:
            a = next((x for x in s.alerts(bid) if x["id"] == alert), None)
            if a is None:
                raise KeyError(alert)
            if a["row_ids"]:
                m &= ch["row_id"].isin(a["row_ids"])
            for col, val in a.get("filter", {}).items():
                if col in ("action", "field", "rule", "group"):
                    m &= ch[col] == val
        if q:
            ql = q.lower()
            m &= ch.apply(lambda r: ql in " ".join(map(str, r.values)).lower(), axis=1)
        sub = ch[m]
        start = (page - 1) * size
        return {"total": int(len(sub)), "page": page, "size": size,
                "items": sub.iloc[start:start + size].to_dict("records"), "facets": facets,
                "verdict_totals": ch["verdict"].value_counts().to_dict()}
    return _guard(go)


@router.get("/batches/{bid}/data")
def data(bid: str, version: Literal["raw", "corrected", "approved", "trusted"] = "corrected",
         page: int = Query(1, ge=1), size: int = Query(50, ge=1, le=500), q: str = "",
         changed_only: bool = False):
    def go():
        s = get_store()
        meta = s.meta(bid)
        idc = meta["columns"]["id_col"]
        df = s.data(bid, version)
        ch = s.changes(bid)
        cells: dict[str, list[str]] = {}
        for rid, f in zip(ch["row_id"], ch["field"]):
            cells.setdefault(rid, []).append(f)
        if changed_only:
            df = df[df[idc].isin(cells.keys())]
        if q:
            df = df[df.apply(lambda r: q.lower() in " ".join(map(str, r.values)).lower(), axis=1)]
        start = (page - 1) * size
        page_df = df.iloc[start:start + size]
        return {"version": version, "columns": list(df.columns), "total": int(len(df)), "page": page,
                "rows": page_df.to_dict("records"),
                "changed_cells": {r: cells[r] for r in page_df[idc] if r in cells}, "id_col": idc}
    return _guard(go)


@router.get("/batches/{bid}/download/{name}")
def download(bid: str, name: str):
    def go():
        s = get_store()
        if name in ("raw", "corrected", "approved", "trusted"):
            body, mt, fn = s.data(bid, name).to_csv(index=False), "text/csv", f"{bid}_{name}.csv"
        elif name == "changes":
            body, mt, fn = s.changes(bid).to_csv(index=False), "text/csv", f"{bid}_change_log.csv"
        elif name == "alerts":
            body, mt, fn = json.dumps(s.alerts(bid), indent=2), "application/json", f"{bid}_alerts.json"
        elif name == "events":
            body, mt, fn = json.dumps(s.events(bid), indent=2), "application/json", f"{bid}_audit_trail.json"
        elif name == "decision":
            body, mt, fn = json.dumps(s.meta(bid), indent=2, default=str), "application/json", f"{bid}_decision.json"
        elif name == "overrides":
            body, mt, fn = json.dumps(s.overrides(), indent=2), "application/json", "reviewer_overrides.json"
        else:
            raise KeyError(name)
        return StreamingResponse(iter([body]), media_type=mt,
                                 headers={"Content-Disposition": f'attachment; filename="{fn}"'})
    return _guard(go)


@router.post("/batches/{bid}/verdicts")
def verdicts(bid: str, v: Verdicts):
    if not v.change_ids and not v.rule:
        raise HTTPException(400, "give change_ids or rule")
    n = _guard(lambda: get_store().set_verdicts(bid, change_ids=v.change_ids, rule=v.rule,
                                                verdict=v.verdict, note=v.note, reviewer=v.reviewer))
    return {"updated": n}


@router.post("/batches/{bid}/decision")
def decide(bid: str, d: Decision):
    return _guard(lambda: get_store().decide(bid, decision=d.decision, reviewer=d.reviewer, notes=d.notes,
                                             acknowledge_alerts=d.acknowledge_alerts,
                                             findings=[f.model_dump() for f in d.findings]))


@router.get("/batches/{bid}/events")
def events(bid: str):
    return _guard(lambda: get_store().events(bid))


@router.get("/active")
def active():
    return get_store().active() or {}


@router.get("/overrides")
def overrides():
    return get_store().overrides()


@router.get("/health", response_class=PlainTextResponse)
def health():
    return "ok"

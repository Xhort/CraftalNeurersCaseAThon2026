"""
Itemized change ledger.

The safest way to get a COMPLETE list of everything the algorithm did is to
diff the data before and after the safeguard, rather than trusting the
algorithm to log itself. `diff_to_changes` does that, row by row and field by
field. If the corrected frame carries a column naming the rule that touched
each row (e.g. `_rule`) and/or a reason (`_reason`), those are attached.

Actions recorded:
  exclude      row present before, gone after
  added        row present after, not before (should never happen -> alert)
  reweight     a weight column changed (e.g. trust weight 1.0 -> 0.35)
  defer        a deferral flag turned on
  impute       a missing value was filled
  value_change any other value change (e.g. back-off toward a default)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

CHANGE_COLUMNS = ["change_id", "row_id", "field", "action", "old_value", "new_value",
                  "delta", "rule", "reason", "group", "verdict", "note"]


def _num(s: pd.Series) -> pd.Series:
    """Numeric view of a column (booleans -> 0/1, text -> NaN)."""
    if s.dtype == bool:
        return s.astype(float)
    return pd.to_numeric(s, errors="coerce").astype(float)


def _same(a: pd.Series, b: pd.Series) -> np.ndarray:
    """Element-wise equality that treats NaN == NaN and tolerates float noise."""
    an, bn = _num(a), _num(b)
    both_num = (an.notna() & bn.notna()).to_numpy()
    num_eq = np.isclose(an.to_numpy(dtype=float), bn.to_numpy(dtype=float), rtol=1e-9, atol=1e-9)
    str_eq = a.astype(str).to_numpy() == b.astype(str).to_numpy()
    both_nan = (a.isna() & b.isna()).to_numpy()
    return both_nan | np.where(both_num, num_eq, str_eq)


def diff_to_changes(raw: pd.DataFrame, corrected: pd.DataFrame, id_col: str,
                    group_col: str | None = None,
                    rule_col: str | None = "_rule", reason_col: str | None = "_reason",
                    weight_col: str | None = "weight", defer_col: str | None = "deferred",
                    new_col_defaults: dict | None = None,
                    field_rules: dict | None = None,
                    ignore: tuple = ()) -> pd.DataFrame:
    """field_rules maps a column to (rule, reason) when one rule always owns that
    column, e.g. {"weight": ("reliability_weighting", "low-trust source")}. Other
    columns take the rule/reason from the row's rule_col / reason_col."""
    field_rules = field_rules or {}
    defaults = {weight_col: 1.0, defer_col: False}
    defaults.update(new_col_defaults or {})
    rule_col = rule_col if rule_col in corrected.columns else None
    reason_col = reason_col if reason_col in corrected.columns else None
    meta_cols = {c for c in (rule_col, reason_col) if c}
    r = raw.set_index(raw[id_col].astype(str), drop=False)
    c = corrected.set_index(corrected[id_col].astype(str), drop=False)
    out = []

    def grp(ids, frame):
        if group_col and group_col in frame.columns:
            return frame.loc[ids, group_col].astype(str).to_numpy()
        return np.array([""] * len(ids))

    removed = r.index.difference(c.index)
    if len(removed):
        out.append(pd.DataFrame({"row_id": removed, "field": "*", "action": "exclude",
                                 "old_value": "row", "new_value": "removed", "delta": np.nan,
                                 "rule": "exclude", "reason": "row removed from the corrected data",
                                 "group": grp(removed, r)}))
    added = c.index.difference(r.index)
    if len(added):
        out.append(pd.DataFrame({"row_id": added, "field": "*", "action": "added",
                                 "old_value": "", "new_value": "row", "delta": np.nan,
                                 "rule": c.loc[added, rule_col].astype(str).to_numpy() if rule_col else "unknown",
                                 "reason": "row exists only in the corrected data", "group": grp(added, c)}))

    common = r.index.intersection(c.index)
    rc, cc = r.loc[common], c.loc[common]
    fields = [f for f in corrected.columns if f not in meta_cols and f != id_col and f not in ignore]
    for f in fields:
        old = rc[f] if f in rc.columns else pd.Series(defaults.get(f, np.nan), index=common)
        new = cc[f]
        diff = ~_same(old, new)
        if not diff.any():
            continue
        ids = common[diff]
        o, n = old[diff], new[diff]
        on, nn = _num(o), _num(n)
        if f == weight_col:
            action = np.full(len(ids), "reweight", dtype=object)
        elif f == defer_col:
            action = np.full(len(ids), "defer", dtype=object)
        else:
            action = np.where(o.isna().to_numpy(), "impute", "value_change").astype(object)
        if f in field_rules:
            fr = field_rules[f] if isinstance(field_rules[f], (tuple, list)) else (field_rules[f], "")
            rule = np.full(len(ids), fr[0], dtype=object)
            reason = np.full(len(ids), fr[1] or f"{f} set by {fr[0]}", dtype=object)
        else:
            rule = cc.loc[ids, rule_col].astype(str).to_numpy() if rule_col else action
            reason = (cc.loc[ids, reason_col].astype(str).to_numpy() if reason_col
                      else np.array([f"{f} changed by the safeguard"] * len(ids)))
            rule = np.where(pd.Series(rule).isin(["", "nan"]), action, rule)
        out.append(pd.DataFrame({
            "row_id": ids, "field": f, "action": action,
            "old_value": o.astype(str).to_numpy(), "new_value": n.astype(str).to_numpy(),
            "delta": (nn - on).to_numpy(), "rule": rule, "reason": reason, "group": grp(ids, c)}))

    if not out:
        return pd.DataFrame(columns=CHANGE_COLUMNS)
    ch = pd.concat(out, ignore_index=True)
    ch.insert(0, "change_id", [f"C{i + 1:06d}" for i in range(len(ch))])
    ch["verdict"] = "pending"
    ch["note"] = ""
    return ch[CHANGE_COLUMNS]

"""Thresholds for the detection system. Change here, not in the checks."""
from dataclasses import dataclass, field


@dataclass
class ReviewConfig:
    # --- plausibility of corrected values (target field, e.g. delivery minutes) ---
    target_min: float = 1.0
    target_max: float = 360.0            # same bounds as the experiment's filter
    max_speed_kmh: float = 60.0          # distance / duration sanity check

    # --- spot check against verified ("trusted") twins ---
    min_spot_checks: int = 20
    moved_away_warn: float = 0.25        # share of corrections that moved AWAY from the trusted value
    moved_away_critical: float = 0.40

    # --- how much was changed ---
    changed_rows_warn: float = 0.50      # share of rows touched by any correction
    single_rule_warn: float = 0.30       # share of rows touched by one rule

    # --- variance collapse (back-off pulled everything to defaults) ---
    std_ratio_warn: float = 0.60

    # --- group / area drift vs trusted records ---
    group_shift_min_abs: float = 3.0     # minutes
    group_shift_min_rel: float = 0.10
    min_group_rows: int = 15

    # --- rare-event protection ---
    rare_group_share: float = 0.05       # a group is "small" if < 5% of rows
    rare_removed_critical: float = 0.50  # >50% of a small group excluded/backed off

    # --- deferral to humans ---
    deferral_warn: float = 0.15          # matches the pilot gate
    deferral_critical: float = 0.90      # "hands everything to people"

    sample_ids: int = 5000               # affected row ids kept per alert (UI shows a sample)

    extra: dict = field(default_factory=dict)

"""
Demo batch so the review console works before the real pipeline is wired in.
Clearly synthetic: LaDe-shaped columns, a noisy fast feed, and a deliberately
imperfect safeguard so the detectors have something real to catch.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_demo(seed: int = 7, n: int = 2000):
    rng = np.random.default_rng(seed)
    regions = np.array(["R1", "R2", "R3", "R4", "R5", "R6-rare"])
    reg = rng.choice(regions, n, p=[.28, .24, .2, .15, .1, .03])
    dist = np.round(np.where(reg == "R6-rare", rng.lognormal(np.log(8), .3, n), rng.lognormal(np.log(2.2), .5, n)), 2)
    base = 12 + 7 * dist + np.where(reg == "R6-rare", 25, 0) + rng.gamma(4, 3, n)
    truth = np.clip(base, 3, 300).round(1)
    source = np.where(rng.random(n) < .45, "fast_feed", "verified")
    noisy = truth.copy()
    m = (source == "fast_feed") & (rng.random(n) < .6)
    noisy[m] = (noisy[m] + rng.exponential(25, m.sum())).round(1)
    age = np.where(np.isin(reg, ["R2"]), rng.uniform(8, 14, n), rng.uniform(0, 1.5, n)).round(1)
    raw = pd.DataFrame({"order_id": [f"O{100000 + i}" for i in range(n)], "region_id": reg,
                        "source": source, "distance_km": dist, "duration_min": noisy,
                        "area_history_age_days": age})
    raw.loc[rng.choice(n, 6, replace=False), "duration_min"] = 520.0   # a few impossible values

    # ---- an intentionally imperfect safeguard ----
    cor = raw.copy()
    cor["weight"] = np.where(cor["source"] == "fast_feed", 0.35, 1.0)
    cor["deferred"] = cor["area_history_age_days"] > 7
    cor["_rule"] = ""      # rule that changed duration_min on this row (if any)
    cor["_reason"] = ""
    med = cor.groupby("region_id")["duration_min"].transform("median")
    p90 = cor["duration_min"].quantile(.90)                                          # citywide p90 (the flaw)
    hi = cor["duration_min"] > p90
    cor.loc[hi, "duration_min"] = (0.3 * cor.loc[hi, "duration_min"] + 0.7 * med[hi]).round(1)
    cor.loc[hi, ["_rule", "_reason"]] = ["safe_input_backoff", "above citywide p90: pulled 70% toward area median"]
    gone = raw["duration_min"] > 360
    cor = cor[~gone.to_numpy()].copy()

    trusted_idx = rng.choice(n, min(700, n // 3), replace=False)   # verified twins for spot checks
    trusted = pd.DataFrame({"order_id": raw["order_id"].iloc[trusted_idx].to_numpy(),
                            "duration_min": truth[trusted_idx]})
    field_rules = {"weight": ("reliability_weighting", "low-trust source: weight 1.0 → 0.35"),
                   "deferred": ("stale_area_deferral", "area history older than 7 days → send to dispatcher")}
    return raw, cor, trusted, field_rules

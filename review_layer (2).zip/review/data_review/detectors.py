"""
Detection system: decides whether the newly corrected data is believed to be
INCORRECT, and explains why.

Each check returns zero or more alerts:
  {id, check, severity: critical|warning|info, title, message, evidence,
   row_ids (sample), filter (how the review UI finds the affected changes),
   suggestion}

Overall status:
  believed_incorrect  - at least one critical alert (accepting requires an
                        explicit human acknowledgement)
  needs_attention     - warnings only
  looks_ok            - nothing above info
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import ReviewConfig


def _alert(check, severity, title, message, evidence=None, row_ids=None, filt=None, suggestion=""):
    return {"check": check, "severity": severity, "title": title, "message": message,
            "evidence": evidence or {}, "row_ids": [] if row_ids is None else [str(x) for x in list(row_ids)],
            "filter": filt or {}, "suggestion": suggestion}


def _r(x, d=2):
    return None if x is None or (isinstance(x, float) and not np.isfinite(x)) else round(float(x), d)


def run_detectors(raw: pd.DataFrame, corrected: pd.DataFrame, changes: pd.DataFrame, *,
                  id_col: str, target: str, group_col: str | None = None,
                  trusted: pd.DataFrame | None = None, distance_col: str | None = None,
                  weight_col: str = "weight", defer_col: str = "deferred",
                  cfg: ReviewConfig | None = None) -> tuple[list[dict], str]:
    cfg = cfg or ReviewConfig()
    A: list[dict] = []
    n_raw = max(len(raw), 1)
    raw_i = raw.set_index(raw[id_col].astype(str), drop=False)
    cor_i = corrected.set_index(corrected[id_col].astype(str), drop=False)
    S = cfg.sample_ids

    # 1. INTEGRITY -------------------------------------------------------------
    dup = cor_i.index[cor_i.index.duplicated()]
    if len(dup):
        A.append(_alert("integrity", "critical", "Duplicate rows in the corrected data",
                        f"{len(dup)} row IDs appear more than once after correction.",
                        {"duplicates": int(len(dup))}, dup[:S], {},
                        "Reject: the safeguard must never duplicate records."))
    added = changes[changes["action"] == "added"]
    if len(added):
        A.append(_alert("integrity", "critical", "Rows were created by the correction",
                        f"{len(added)} rows exist only in the corrected data — the safeguard should adjust or remove data, never invent it.",
                        {"added_rows": int(len(added))}, added["row_id"][:S], {"action": "added"},
                        "Reject these items and find which rule produced them."))

    # 2. PLAUSIBILITY ----------------------------------------------------------
    tgt_new = pd.to_numeric(cor_i[target], errors="coerce")
    tgt_old = pd.to_numeric(raw_i[target], errors="coerce").reindex(cor_i.index)
    bad_new = tgt_new.isna() | (tgt_new < cfg.target_min) | (tgt_new > cfg.target_max)
    if distance_col and distance_col in cor_i.columns:
        dist = pd.to_numeric(cor_i[distance_col], errors="coerce")
        speed = dist / (tgt_new.clip(lower=1e-6) / 60)
        bad_new |= speed > cfg.max_speed_kmh
    bad_old = tgt_old.isna() | (tgt_old < cfg.target_min) | (tgt_old > cfg.target_max)
    introduced = bad_new & ~bad_old
    if introduced.any():
        A.append(_alert("plausibility", "critical", "Correction produced impossible values",
                        f"{int(introduced.sum())} rows were valid before correction and are impossible after "
                        f"({target} outside {cfg.target_min:g}–{cfg.target_max:g} or implied speed > {cfg.max_speed_kmh:g} km/h).",
                        {"rows": int(introduced.sum())}, cor_i.index[introduced][:S], {"field": target},
                        "Reject the affected items."))
    pre = bad_new & bad_old
    if pre.any():
        A.append(_alert("plausibility", "info", "Impossible values the correction did not fix",
                        f"{int(pre.sum())} rows were already implausible and still are.",
                        {"rows": int(pre.sum())}, cor_i.index[pre][:S], {}, "Consider excluding them."))

    # 3. SPOT CHECK AGAINST VERIFIED TWINS (strongest evidence) ---------------
    tchg = changes[(changes["field"] == target) & changes["action"].isin(["value_change", "impute"])]
    if trusted is not None and len(tchg):
        tr = trusted.set_index(trusted[id_col].astype(str))[target]
        tr = pd.to_numeric(tr[~tr.index.duplicated()], errors="coerce")
        sub = tchg[tchg["row_id"].isin(tr.index)].copy()
        if len(sub) >= cfg.min_spot_checks:
            truth = tr.reindex(sub["row_id"]).to_numpy()
            old = pd.to_numeric(sub["old_value"], errors="coerce").to_numpy()
            new = pd.to_numeric(sub["new_value"], errors="coerce").to_numpy()
            e_old, e_new = np.abs(old - truth), np.abs(new - truth)
            away = e_new > e_old + 1e-9
            share = float(np.nanmean(away))
            sev = "critical" if share >= cfg.moved_away_critical else "warning" if share >= cfg.moved_away_warn else "info"
            A.append(_alert(
                "spot_check", sev,
                "Corrections moved values AWAY from verified records" if sev != "info" else "Spot check against verified records passed",
                f"{len(sub)} corrected values have a verified twin. {share:.0%} of corrections made the value less accurate; "
                f"average error vs verified went from {np.nanmean(e_old):.1f} to {np.nanmean(e_new):.1f} min.",
                {"spot_checks": int(len(sub)), "moved_away_share": _r(share, 3),
                 "mae_before": _r(np.nanmean(e_old)), "mae_after": _r(np.nanmean(e_new))},
                sub.loc[away, "row_id"][:S], {"field": target},
                "Reject the rule(s) responsible, or the batch." if sev != "info" else ""))
        else:
            A.append(_alert("spot_check", "info", "Too few verified twins to spot-check",
                            f"Only {len(sub)} corrected values have a verified twin (need {cfg.min_spot_checks}).",
                            {"spot_checks": int(len(sub))}))
    elif trusted is None:
        A.append(_alert("spot_check", "info", "No verified records supplied",
                        "Without verified twins the system cannot measure whether corrections moved values toward the truth.",
                        suggestion="Pass a sample of verified records to submit_for_review(trusted=...)."))

    # 4. HOW MUCH WAS CHANGED -------------------------------------------------
    if len(changes):
        touched = changes["row_id"].nunique() / n_raw
        if touched >= cfg.changed_rows_warn:
            A.append(_alert("volume", "warning", "Most of the data was changed",
                            f"{touched:.0%} of rows were changed by the safeguard.", {"rows_changed_share": _r(touched, 3)},
                            suggestion="Check that a rule is not firing on normal data."))
        per_rule = changes.groupby("rule")["row_id"].nunique() / n_raw
        for rule, sh in per_rule[per_rule >= cfg.single_rule_warn].items():
            A.append(_alert("volume", "warning", f"Rule “{rule}” touched {sh:.0%} of rows",
                            "A single rule changing this much data usually means its threshold is too loose.",
                            {"rule": rule, "share": _r(sh, 3)}, filt={"rule": rule},
                            suggestion="Review a sample; reject the rule if it is firing on normal records."))

    # 5. VARIANCE COLLAPSE -----------------------------------------------------
    common = cor_i.index.intersection(raw_i.index)
    s_old = pd.to_numeric(raw_i.loc[common, target], errors="coerce").std()
    s_new = pd.to_numeric(cor_i.loc[common, target], errors="coerce").std()
    if s_old and np.isfinite(s_old) and s_new / s_old < cfg.std_ratio_warn:
        A.append(_alert("variance", "warning", f"Correction flattened {target}",
                        f"Spread of {target} fell from {s_old:.1f} to {s_new:.1f} (×{s_new / s_old:.2f}). "
                        "Back-off toward defaults may be erasing real variation.",
                        {"std_before": _r(s_old), "std_after": _r(s_new)}, filt={"field": target},
                        suggestion="Loosen the back-off or reject it for this field."))

    # 6. GROUP DRIFT AGAINST VERIFIED RECORDS ---------------------------------
    if trusted is not None and group_col and group_col in cor_i.columns:
        tr = trusted.set_index(trusted[id_col].astype(str))[target]
        tr = pd.to_numeric(tr[~tr.index.duplicated()], errors="coerce")
        ids = common.intersection(tr.index)
        if len(ids):
            df = pd.DataFrame({"g": cor_i.loc[ids, group_col].astype(str),
                               "old": pd.to_numeric(raw_i.loc[ids, target], errors="coerce"),
                               "new": pd.to_numeric(cor_i.loc[ids, target], errors="coerce"),
                               "truth": tr.reindex(ids)})
            for g, d in df.groupby("g"):
                if len(d) < cfg.min_group_rows:
                    continue
                dev_new = abs(d["new"].mean() - d["truth"].mean())
                dev_old = abs(d["old"].mean() - d["truth"].mean())
                lim = max(cfg.group_shift_min_abs, cfg.group_shift_min_rel * d["truth"].mean())
                if dev_new > lim and dev_new > dev_old:
                    A.append(_alert("group_drift", "warning", f"Area {g}: corrected data drifted from verified records",
                                    f"Mean {target} is {dev_new:.1f} min from verified (was {dev_old:.1f} before correction).",
                                    {"group": g, "deviation_before": _r(dev_old), "deviation_after": _r(dev_new), "rows": int(len(d))},
                                    d.index[:S], {"group": g}, "Inspect this area's changes."))

    # 7. RARE-EVENT PROTECTION ------------------------------------------------
    if group_col and group_col in raw_i.columns:
        sizes = raw_i[group_col].astype(str).value_counts()
        hit = changes[(changes["action"] == "exclude") | ((changes["field"] == target) & (changes["action"] == "value_change"))]
        hit_g = hit.groupby("group")["row_id"].nunique()
        for g, size in sizes.items():
            if size / n_raw >= cfg.rare_group_share:
                continue
            share = hit_g.get(g, 0) / size
            if share > cfg.rare_removed_critical:
                A.append(_alert("rare_events", "critical", f"Small area {g}: {share:.0%} of its records removed or overwritten",
                                f"Area {g} is only {size / n_raw:.1%} of the data. Records that are rare are not automatically wrong — "
                                "the safeguard may be deleting valid unusual deliveries.",
                                {"group": g, "group_rows": int(size), "affected_share": _r(share, 3)},
                                hit[hit["group"] == g]["row_id"][:S], {"group": g},
                                "Reject these changes unless the records are verified bad."))

    # 8. DEFERRAL -------------------------------------------------------------
    if defer_col in cor_i.columns:
        dfl = cor_i[defer_col].astype(str).str.lower().isin(["true", "1", "yes"])
        share = float(dfl.mean()) if len(dfl) else 0.0
        if share >= cfg.deferral_critical:
            A.append(_alert("deferral", "critical", f"{share:.0%} of rows sent to human review",
                            "The safeguard is not correcting this data; it is handing nearly all of it to people.",
                            {"deferred_share": _r(share, 3)}, cor_i.index[dfl][:S], {"action": "defer"},
                            "Reject and redesign the deferral rule."))
        elif share > cfg.deferral_warn:
            A.append(_alert("deferral", "warning", f"{share:.0%} of rows sent to human review",
                            f"Above the {cfg.deferral_warn:.0%} workload gate.", {"deferred_share": _r(share, 3)},
                            filt={"action": "defer"}))
        if group_col and group_col in cor_i.columns:
            gshare = dfl.groupby(cor_i[group_col].astype(str)).mean()
            for g, sh in gshare[gshare >= cfg.deferral_critical].items():
                if share < cfg.deferral_critical:
                    A.append(_alert("deferral", "warning", f"Area {g}: {sh:.0%} deferred",
                                    "Every ETA in this area goes to a person.", {"group": g, "deferred_share": _r(sh, 3)},
                                    filt={"action": "defer", "group": g}))

    # 9. WEIGHTS --------------------------------------------------------------
    if weight_col in cor_i.columns:
        w = pd.to_numeric(cor_i[weight_col], errors="coerce")
        bad = w.isna() | (w < 0)
        if bad.any():
            A.append(_alert("weights", "critical", "Invalid trust weights", f"{int(bad.sum())} rows have missing or negative weights.",
                            {"rows": int(bad.sum())}, cor_i.index[bad][:S], {"field": weight_col}, "Reject."))

    for i, a in enumerate(A):
        a["id"] = f"A{i + 1:03d}"
    order = {"critical": 0, "warning": 1, "info": 2}
    A.sort(key=lambda a: order[a["severity"]])
    status = ("believed_incorrect" if any(a["severity"] == "critical" for a in A)
              else "needs_attention" if any(a["severity"] == "warning" for a in A) else "looks_ok")
    return A, status

"""
File-based store for review batches. One folder per batch:

  meta.json        summary, status, decision
  raw.csv          data BEFORE the safeguard (untouched copy)
  corrected.csv    data AFTER the safeguard
  trusted.csv      optional verified records used for spot checks
  changes.csv      itemized ledger, one row per change, with human verdicts
  alerts.json      detection results
  events.jsonl     audit trail of every system and human action
  approved.csv     dataset built from the human decision (accepted changes only)

Plus, at the store root:
  active.json               which approved dataset the model should use now
  reviewer_overrides.json   findings to apply on the next safeguard run
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timezone

import numpy as np
import pandas as pd

LOCK = threading.RLock()
VERDICTS = {"pending", "accepted", "rejected"}
FINDING_TYPES = {"disable_rule", "set_threshold", "source_trust", "exclude_rows", "note"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ReviewError(ValueError):
    pass


class ReviewStore:
    def __init__(self, root: str | None = None):
        self.root = root or os.environ.get("DATA_REVIEW_DIR", "data_review_store")
        os.makedirs(self.root, exist_ok=True)

    # ------------------------------------------------------------------ paths
    def _p(self, bid: str, name: str = "") -> str:
        if not bid or any(c in bid for c in "/\\.") :
            raise ReviewError("bad batch id")
        path = os.path.join(self.root, bid, name)
        if not os.path.isdir(os.path.join(self.root, bid)):
            raise KeyError(bid)
        return path

    def _read_json(self, path, default=None):
        if not os.path.exists(path):
            return default
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def _write_json(self, path, obj):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, default=str)
        os.replace(tmp, path)

    def log(self, bid: str, actor: str, event: str, **details):
        with open(self._p(bid, "events.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps({"at": _now(), "actor": actor, "event": event, **details}, default=str) + "\n")

    # ----------------------------------------------------------------- create
    def create(self, raw, corrected, changes, alerts, status, meta, trusted=None) -> str:
        bid = datetime.now().strftime("B%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
        d = os.path.join(self.root, bid)
        os.makedirs(d)
        raw.to_csv(os.path.join(d, "raw.csv"), index=False)
        corrected.to_csv(os.path.join(d, "corrected.csv"), index=False)
        if trusted is not None:
            trusted.to_csv(os.path.join(d, "trusted.csv"), index=False)
        changes.to_csv(os.path.join(d, "changes.csv"), index=False)
        self._write_json(os.path.join(d, "alerts.json"), alerts)
        counts = {s: sum(a["severity"] == s for a in alerts) for s in ("critical", "warning", "info")}
        meta = {**meta, "id": bid, "created_at": _now(), "status": "pending_review", "detection": status,
                "alert_counts": counts, "rows_raw": int(len(raw)), "rows_corrected": int(len(corrected)),
                "changes": int(len(changes)), "has_trusted": trusted is not None,
                "changes_by_action": changes["action"].value_counts().to_dict() if len(changes) else {},
                "decision": None}
        self._write_json(os.path.join(d, "meta.json"), meta)
        self.log(bid, "system", "batch_created", rows=len(raw), changes=len(changes))
        self.log(bid, "system", "detection_completed", status=status, alerts=counts)
        return bid

    # ------------------------------------------------------------------ reads
    def list(self) -> list[dict]:
        out = []
        for name in sorted(os.listdir(self.root), reverse=True):
            m = self._read_json(os.path.join(self.root, name, "meta.json"))
            if m:
                out.append(m)
        return out

    def meta(self, bid):
        return self._read_json(self._p(bid, "meta.json"))

    def alerts(self, bid):
        return self._read_json(self._p(bid, "alerts.json"), [])

    def changes(self, bid) -> pd.DataFrame:
        df = pd.read_csv(self._p(bid, "changes.csv"), dtype=str, keep_default_na=False)
        return df

    def data(self, bid, version: str) -> pd.DataFrame:
        if version not in ("raw", "corrected", "approved", "trusted"):
            raise ReviewError("unknown version")
        path = self._p(bid, f"{version}.csv")
        if not os.path.exists(path):
            raise KeyError(version)
        return pd.read_csv(path, dtype=str, keep_default_na=False)

    def events(self, bid) -> list[dict]:
        path = self._p(bid, "events.jsonl")
        if not os.path.exists(path):
            return []
        with open(path, encoding="utf-8") as f:
            return [json.loads(x) for x in f if x.strip()]

    # ----------------------------------------------------------- item verdicts
    def _locked(self, bid):
        m = self.meta(bid)
        if m["status"] not in ("pending_review",):
            raise ReviewError(f"batch already decided ({m['status']})")
        return m

    def set_verdicts(self, bid, *, change_ids=None, rule=None, verdict="pending", note="", reviewer="reviewer"):
        if verdict not in VERDICTS:
            raise ReviewError("verdict must be pending, accepted or rejected")
        with LOCK:
            self._locked(bid)
            ch = self.changes(bid)
            if rule is not None:
                mask = ch["rule"] == rule
            else:
                mask = ch["change_id"].isin(change_ids or [])
            if not mask.any():
                raise ReviewError("no matching changes")
            ch.loc[mask, "verdict"] = verdict
            if note:
                ch.loc[mask, "note"] = note
            ch.to_csv(self._p(bid, "changes.csv"), index=False)
            self.log(bid, reviewer, "items_marked", verdict=verdict, count=int(mask.sum()),
                     rule=rule, change_ids=(None if rule else list(ch.loc[mask, "change_id"])[:200]), note=note)
            return int(mask.sum())

    # ---------------------------------------------------------------- decision
    def decide(self, bid, *, decision: str, reviewer: str, notes: str = "",
               acknowledge_alerts: bool = False, findings: list | None = None) -> dict:
        if decision not in ("accept", "reject"):
            raise ReviewError("decision must be accept or reject")
        if not reviewer.strip():
            raise ReviewError("reviewer name is required")
        findings = findings or []
        for f in findings:
            if f.get("type") not in FINDING_TYPES:
                raise ReviewError(f"unknown finding type {f.get('type')!r}")
            if f["type"] != "note" and not str(f.get("target", "")).strip():
                raise ReviewError(f"finding '{f['type']}' needs a target")
            if f["type"] == "source_trust":
                try:
                    v = float(f.get("value"))
                except (TypeError, ValueError):
                    raise ReviewError("source_trust needs a number between 0 and 1")
                if not 0 <= v <= 1:
                    raise ReviewError("source_trust needs a number between 0 and 1")
        with LOCK:
            m = self._locked(bid)
            cfg = m["columns"]
            id_col, weight_col, defer_col = cfg["id_col"], cfg["weight_col"], cfg["defer_col"]
            crit = m["alert_counts"].get("critical", 0)
            if decision == "accept" and crit and not acknowledge_alerts:
                raise ReviewError(f"{crit} critical alert(s): tick the acknowledgement to accept anyway")
            if (decision == "reject" or (decision == "accept" and crit)) and len(notes.strip()) < 10:
                raise ReviewError("write a short reason (at least 10 characters)")
            ch = self.changes(bid)
            if decision == "accept":
                ch.loc[ch["verdict"] == "pending", "verdict"] = "accepted"
            else:
                ch.loc[ch["verdict"] != "rejected", "verdict"] = "rejected"
            ch.to_csv(self._p(bid, "changes.csv"), index=False)

            # rules whose every change was rejected -> automatic "disable rule" finding
            auto = []
            for rule, g in ch.groupby("rule"):
                if (g["verdict"] == "rejected").all() and decision == "accept":
                    auto.append({"type": "disable_rule", "target": rule, "value": "",
                                 "text": f"All {len(g)} changes from this rule were rejected.", "auto": True})
            all_findings = findings + auto

            raw = self.data(bid, "raw")
            approved = None
            if decision == "accept":
                approved = self._build_approved(bid, raw, ch, all_findings, id_col, weight_col, defer_col)
                approved.to_csv(self._p(bid, "approved.csv"), index=False)
                self._write_json(os.path.join(self.root, "active.json"),
                                 {"batch_id": bid, "path": self._p(bid, "approved.csv"), "rows": int(len(approved)),
                                  "approved_by": reviewer, "at": _now()})
            self._merge_overrides(bid, reviewer, all_findings)

            vc = ch.groupby(["action", "verdict"]).size().unstack(fill_value=0)
            summary = {k: {kk: int(vv) for kk, vv in v.items()} for k, v in vc.to_dict("index").items()}
            accepted = int((ch["verdict"] == "accepted").sum())
            m["status"] = ("rejected" if decision == "reject"
                           else "approved" if accepted == len(ch) else "partially_approved")
            m["decision"] = {"decision": decision, "reviewer": reviewer, "notes": notes, "at": _now(),
                             "acknowledged_alerts": bool(acknowledge_alerts), "findings": all_findings,
                             "accepted": accepted, "rejected": int((ch["verdict"] == "rejected").sum()),
                             "by_action": summary, "approved_rows": None if approved is None else int(len(approved))}
            self._write_json(self._p(bid, "meta.json"), m)
            self.log(bid, reviewer, "decision", decision=decision, status=m["status"], notes=notes,
                     acknowledged_alerts=bool(acknowledge_alerts), findings=len(all_findings))
            return m

    def _build_approved(self, bid, raw, ch, findings, id_col, weight_col, defer_col) -> pd.DataFrame:
        """Start from the untouched data; apply ONLY accepted changes; then apply findings."""
        cor = self.data(bid, "corrected")
        a = raw.set_index(raw[id_col].astype(str), drop=False)
        c = cor.set_index(cor[id_col].astype(str), drop=False)
        acc = ch[ch["verdict"] == "accepted"]
        for f, g in acc[~acc["field"].isin(["*"])].groupby("field"):
            if f not in a.columns:
                a[f] = {weight_col: "1.0", defer_col: "False"}.get(f, "")
            ids = g["row_id"][g["row_id"].isin(c.index) & g["row_id"].isin(a.index)]
            a.loc[ids, f] = c.loc[ids, f].to_numpy()
        drop = acc.loc[acc["action"] == "exclude", "row_id"]
        a = a.drop(index=a.index.intersection(drop))
        add = acc.loc[acc["action"] == "added", "row_id"]
        if len(add):
            a = pd.concat([a, c.loc[c.index.intersection(add), [col for col in c.columns if col in a.columns]]])
        for f in findings:
            if f["type"] == "exclude_rows":
                ids = [x.strip() for x in str(f.get("target", "")).replace("\n", ",").split(",") if x.strip()]
                a = a.drop(index=a.index.intersection(ids))
        drop_meta = [x for x in a.columns if x.startswith("_")]
        a = a.drop(columns=drop_meta)
        a["_approved_from_batch"] = bid
        return a.reset_index(drop=True)

    def _merge_overrides(self, bid, reviewer, findings):
        path = os.path.join(self.root, "reviewer_overrides.json")
        o = self._read_json(path, {"disabled_rules": [], "thresholds": {}, "source_trust": {},
                                   "excluded_rows": [], "notes": [], "history": []})
        for f in findings:
            t, tgt, val = f["type"], str(f.get("target", "")).strip(), f.get("value", "")
            if t == "disable_rule" and tgt and tgt not in o["disabled_rules"]:
                o["disabled_rules"].append(tgt)
            elif t == "set_threshold" and tgt:
                try:
                    o["thresholds"][tgt] = float(val)
                except (TypeError, ValueError):
                    o["thresholds"][tgt] = val
            elif t == "source_trust" and tgt:
                o["source_trust"][tgt] = float(np.clip(float(val), 0, 1))
            elif t == "exclude_rows":
                o["excluded_rows"] = sorted(set(o["excluded_rows"]) | {x.strip() for x in tgt.replace("\n", ",").split(",") if x.strip()})
            if f.get("text"):
                o["notes"].append({"batch": bid, "by": reviewer, "type": t, "target": tgt, "text": f["text"]})
        o["history"].append({"batch": bid, "by": reviewer, "at": _now(), "findings": len(findings)})
        self._write_json(path, o)

    def overrides(self) -> dict:
        return self._read_json(os.path.join(self.root, "reviewer_overrides.json"), {})

    def active(self) -> dict | None:
        return self._read_json(os.path.join(self.root, "active.json"))

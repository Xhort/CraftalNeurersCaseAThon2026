"""
Minimal FastAPI app showing the integration. Run:  uvicorn example_app:app --reload
Then open http://127.0.0.1:8000/  (the review console) and click "Create demo batch".

In your real app you only need:
    from data_review.router import router as review_router
    app.include_router(review_router)
and paste review-console-section.html into your page.
"""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from data_review.router import router as review_router

app = FastAPI(title="ETA Reliability Lab — review demo")
app.include_router(review_router)

SECTION = Path(__file__).with_name("review-console-section.html")


@app.get("/", response_class=HTMLResponse)
def index():
    return ("<!doctype html><html><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>Data review</title></head><body style='margin:0;background:#0b1220'>"
            + SECTION.read_text(encoding="utf-8") + "</body></html>")

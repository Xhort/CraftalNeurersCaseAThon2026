# Data review layer — detection, itemized audit, human accept/reject

Nothing the safeguard changes is used until a person signs off.

```
safeguard runs ──► submit_for_review(raw, corrected, …)
                     ├─ itemized change log (diff of before vs after, every row × field)
                     ├─ detection system → alerts + "believed_incorrect / needs_attention / looks_ok"
                     └─ batch saved ──► Review console on the website
                                          ├─ Alerts       (why the data may be wrong, links to affected changes)
                                          ├─ Change log   (filter, accept/reject items, notes)
                                          ├─ By rule      (accept/reject everything a rule did)
                                          ├─ Data         (before / after / approved / verified, changed cells highlighted, CSV downloads)
                                          ├─ Decision     (accept or reject + findings)
                                          └─ Audit trail  (every system and human action)
Accept ─► approved dataset = original data + ONLY accepted changes + findings  → get_active_dataset()
Findings ─► reviewer_overrides.json → get_reviewer_overrides() on the next safeguard run
```

## Files
| Path | Purpose |
|---|---|
| `data_review/pipeline.py` | `submit_for_review`, `get_active_dataset`, `get_reviewer_overrides` — the 3 calls your code uses |
| `data_review/ledger.py` | Builds the itemized change list by diffing before vs after |
| `data_review/detectors.py` | The detection checks (below) |
| `data_review/config.py` | All thresholds |
| `data_review/store.py` | Batches, verdicts, decisions, audit trail, approved dataset, overrides (files on disk) |
| `data_review/router.py` | FastAPI routes under `/api/review` |
| `data_review/demo.py` | Synthetic demo batch (button on the page) |
| `review-console-section.html` | Drop-in page section (no build step) |
| `example_app.py` | Minimal app wiring it all together |

## Install into your FastAPI app
```python
from data_review.router import router as review_router
app.include_router(review_router)
```
Paste `review-console-section.html` into the page (e.g. after the Human review section).
Optional: `DATA_REVIEW_DIR=/path/to/store` (default `./data_review_store`).

Try it alone: `uvicorn example_app:app --reload` → open http://127.0.0.1:8000 → **Create demo batch**.

## Wire it to your safeguard (3 lines)
```python
from data_review import submit_for_review, get_active_dataset, get_reviewer_overrides

overrides = get_reviewer_overrides()            # before the run: apply reviewer findings
#   overrides["disabled_rules"]  -> skip these rules
#   overrides["source_trust"]    -> e.g. {"fast_feed": 0.5}
#   overrides["thresholds"]      -> e.g. {"backoff_quantile": 0.97}
#   overrides["excluded_rows"]   -> order_ids to drop

corrected = run_safeguard(raw, overrides)       # YOUR code, unchanged otherwise

submit_for_review(raw, corrected, id_col="order_id", target="duration_min",
                  group_col="region_id", distance_col="distance_km",
                  trusted=verified_sample,       # rows with verified durations (strongly recommended)
                  field_rules={"weight": ("reliability_weighting", "low-trust source"),
                               "deferred": ("human_deferral", "high-risk ETA")},
                  scenario="combined")

train_df = get_active_dataset()                 # train/serve ONLY on human-approved data
```
If your safeguard writes a `_rule` column (and optionally `_reason`) naming the rule that changed
each row, the change log shows it; otherwise use `field_rules`.

## What the detection system checks
| Check | Severity | Fires when |
|---|---|---|
| Integrity | critical | duplicated rows, or rows that exist only after correction |
| Plausibility | critical | correction makes a valid value impossible (outside 1–360 min, > 60 km/h) |
| Spot check vs verified records | warning / critical | ≥ 25% / 40% of corrections move the value **away** from its verified twin |
| Volume | warning | > 50% of rows changed, or one rule touches > 30% |
| Variance collapse | warning | back-off shrinks the spread of the target below 60% |
| Area drift | warning | an area's corrected mean moves further from verified records than before |
| Rare events | critical | a small area (< 5% of rows) has > 50% of records removed or overwritten |
| Deferral | warning / critical | > 15% / ≥ 90% of rows sent to humans (overall or per area) |
| Weights | critical | missing or negative trust weights |

Any critical → **"believed incorrect"**: a banner on the page, and accepting requires a written
reason plus an explicit acknowledgement. All thresholds are in `config.py`.

## Accept / reject rules
- **Accept**: unmarked changes are accepted, rejected items are left out. Approved data is rebuilt from the
  *original* data plus accepted changes, then findings (row exclusions) are applied. It becomes the active dataset.
- **Reject**: nothing changes in the active dataset; a reason is required; findings are still saved.
- Rejecting every change of a rule automatically adds a "disable rule" finding.
- Decided batches are locked. Every mark and decision is in the audit trail with who and when.

## Not included (say so if asked)
- No login: the reviewer name is typed in. Put the routes behind your site's auth before public use.
- File-based storage is fine for the competition; use a database for multiple simultaneous reviewers.
